package com.quotes.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import org.springframework.boot.test.mock.mockito.MockBean;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.hamcrest.Matchers.hasSize;
import com.quotes.model.entity.Quote;

import io.micrometer.core.ipc.http.HttpSender.Response;

import static org.hamcrest.core.Is.is;


@RunWith(SpringRunner.class)
@WebMvcTest(QuoteController.class)
public class QuoteControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private QuoteController quoteController;
	
	@Test
	public void getAllQuotes() throws Exception {
		List<Quote> quoteVoGrp = new ArrayList<Quote>();
		Quote quote1 = new Quote();
		quote1.setId((long) 1);
		quote1.setQuote("Whether you think you can, or you can't");
		quote1.setAuthor("Henry Ford");
		quoteVoGrp.add(quote1);
		Quote quote2 = new Quote();
		quote2.setId((long) 2);
		quote2.setQuote("I think, therefore, I can");
		quote2.setAuthor("Aristotle");
		quoteVoGrp.add(quote2);

	       mvc.perform(get("/quotes")
	               .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	               .andExpect(status().isOk())
	               .andExpect(jsonPath("$", hasSize(1)))
	               .andExpect(jsonPath("$[0].id", is(quote1.getId())))
	               .andExpect(jsonPath("$[0].quote", is(quote1.getQuote())))
	               .andExpect(jsonPath("$[0].author", is(quote1.getAuthor())))
	               
	               .andExpect(jsonPath("$[1].id", is(quote2.getId())))
	               .andExpect(jsonPath("$[1].quote", is(quote2.getQuote())))
	               .andExpect(jsonPath("$[1].author", is(quote2.getAuthor())))
	               ;
	       
	}
	
	@Test
	public void getQuotes() throws Exception {
		Quote quote2 = new Quote();
		quote2.setId((long) 2);
		quote2.setQuote("I think, therefore, I can");
		quote2.setAuthor("Aristotle");
		
		 given(quoteController.getQuote(2)).willReturn(quote2);

	       mvc.perform(get("/quotes/2")
	               .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	               .andExpect(status().isOk())
	               .andExpect(jsonPath("$", hasSize(1)))
	               .andExpect(jsonPath("$[0].id", is(quote2.getId())))
	               .andExpect(jsonPath("$[0].quote", is(quote2.getQuote())))
	               .andExpect(jsonPath("$[0].author", is(quote2.getAuthor())))
	               ;
	       
	}
	
	
	
}
