package com.quotes;

public class AbstractTest {

}
