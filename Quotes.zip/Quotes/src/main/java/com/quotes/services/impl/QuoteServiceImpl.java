package com.quotes.services.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quotes.auxiliary.exception.QuoteNotFoundException;
import com.quotes.model.dao.QuoteRepository;
import com.quotes.model.entity.Quote;
import com.quotes.services.interfaces.QuoteService;

@Service
public class QuoteServiceImpl implements QuoteService{

	@Autowired
	QuoteRepository quoteRepository;
	
	
	@Override
	public List<Quote> findAll() {
		// TODO Auto-generated method stub
		return quoteRepository.findAll();
	}


	@Override
	public Optional<Quote> findById(long id) {
		// TODO Auto-generated method stub
		Optional<Quote> quote = quoteRepository.findById(id);
		if(quote==null) {
			throw new QuoteNotFoundException("id");
		}
				
		return quote;
	}


	@Override
	public Quote save(Quote quote) {
		// TODO Auto-generated method stub
		return quoteRepository.save(quote);
	}


	@Override
	public void deleteById(long id) {
		// TODO Auto-generated method stub
		quoteRepository.deleteById(id);	
	}


	
}
