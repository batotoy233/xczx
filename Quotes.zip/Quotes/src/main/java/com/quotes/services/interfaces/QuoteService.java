package com.quotes.services.interfaces;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.quotes.model.entity.Quote;

@Service
public interface QuoteService{

	List<Quote> findAll();

	Optional<Quote> findById(long id);

	Quote save(Quote quote);

	void deleteById(long id);


}
