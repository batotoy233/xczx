package com.quotes.auxiliary.exception;

public class QuoteNotFoundException extends RuntimeException {
	private String id;

	public QuoteNotFoundException(String id) {
	super(String.format(" not found : '%s'",id));
	this.id=id;

	}

	public String getId() {
	return this.id;
	}
}
