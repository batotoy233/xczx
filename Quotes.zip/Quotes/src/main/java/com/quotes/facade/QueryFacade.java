package com.quotes.facade;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.quotes.model.entity.Quote;
import com.quotes.services.interfaces.QuoteService;

@Component
public class QueryFacade {

	@Autowired
	QuoteService quoteService;
	
	
	
	public List<Quote> findAllQuote() {
		// TODO Auto-generated method stub
		return quoteService.findAll();
	}



	public Optional<Quote> findQuoteById(long id) {
		// TODO Auto-generated method stub
		return quoteService.findById(id);
	}

}
