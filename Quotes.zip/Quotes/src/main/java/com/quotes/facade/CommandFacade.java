package com.quotes.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.quotes.model.entity.Quote;
import com.quotes.services.interfaces.QuoteService;

@Component
public class CommandFacade {

	@Autowired
	QuoteService quoteService;
	
	@Autowired
	JpaRepository jpaRepository;
	
	public Quote save(Quote quote) {
		// TODO Auto-generated method stub
		return quoteService.save(quote);
	}


	public void deleteQuoteById(long id) {
		// TODO Auto-generated method stub
		quoteService.deleteById(id);
	}


}
