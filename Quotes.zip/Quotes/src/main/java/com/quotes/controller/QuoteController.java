package com.quotes.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.quotes.auxiliary.exception.QuoteNotFoundException;
import com.quotes.facade.CommandFacade;
import com.quotes.facade.QueryFacade;
import com.quotes.model.entity.Quote;

@RestController
public class QuoteController {

	@Autowired
	QueryFacade queryFacade;
	@Autowired
	CommandFacade commandFacade;
	
	@GetMapping(value="/quotes") //GET
	public List<Quote> getAllQuotes() {
		return queryFacade.findAllQuote();
	}
	
	@GetMapping(value="/quotes/{id}") //GET
	public Quote getQuote(@PathVariable long id) {
		Optional<Quote> quoteVo= queryFacade.findQuoteById(id);
		if(!quoteVo.isPresent()) {
			throw new QuoteNotFoundException("id-" + id);
		}
		return quoteVo.get();
	}
	
	@PostMapping(value="/quotes") //POST
	public ResponseEntity<Object> createStudent(@RequestBody Quote quote) {
		Quote savedQuote = commandFacade.save(quote);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedQuote.getId()).toUri();

		return ResponseEntity.created(location).body(savedQuote);
	}
	
	@DeleteMapping(value="/quotes/{id}") //DELETE
	public ResponseEntity<Void> deleteStudent(@PathVariable long id) {
		commandFacade.deleteQuoteById(id);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/quotes/{id}") //PUT
	public ResponseEntity<Object> updateStudent(@RequestBody Quote quote, @PathVariable long id) {

		Optional<Quote> quoteVo = queryFacade.findQuoteById(id);

		if (!quoteVo.isPresent())
			return ResponseEntity.notFound().build();

		quote.setId(id);
		
		commandFacade.save(quote);

		return ResponseEntity.accepted().body(quote);
	}
}
