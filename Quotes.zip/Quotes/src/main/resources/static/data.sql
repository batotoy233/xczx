insert into quotes
values(1,"Whether you think you can, or you cant","Henry Ford");

insert into quotes
values(2,"I think therefore i can","Aristotle");